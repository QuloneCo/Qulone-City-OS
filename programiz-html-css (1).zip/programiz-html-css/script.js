function saveData() {
  // Get the username and password from the form.
  const username = document.querySelector('input[name="username"]').value;
  const password = document.querySelector('input[name="password"]').value;

  // Save the data to a local storage variable.
  localStorage.setItem('username', username);
  localStorage.setItem('password', password);

  // Display a message to the user.
  alert('Data saved successfully!');
}

// Add an event listener to the submit button.
document.querySelector('a').addEventListener('click', saveData);
